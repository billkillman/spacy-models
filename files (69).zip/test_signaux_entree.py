"""Tests du calcul des signaux d'entrée et des outils statistiques de la référence."""
import json
from pathlib import Path

import pytest

import calculer_reference as ref
import signaux_entree as sig


# ------------------------------------------------------------------ descripteurs
def test_descripteurs_de_base():
    d = sig.descripteurs("Bonjour, je conteste ces frais prélevés par [NOM] ! Merci !")
    assert d["nb_exclamations"] == 2
    assert d["nb_jetons_anonymisation"] == 1
    assert d["longueur_mots"] == 8             # le jeton [NOM] n'est pas compté comme un mot
    assert d["encodage_suspect"] == "non"
    assert d["langue"] == "fr"


def test_encodage_casse_detecte():
    assert sig.descripteurs("Le prÃ©lÃ¨vement nâ€™a pas eu lieu")["encodage_suspect"] == "oui"
    assert sig.descripteurs("Caractère perdu \ufffd ici")["encodage_suspect"] == "oui"


def test_majuscules():
    assert sig.descripteurs("JE SUIS EN COLERE")["part_majuscules"] == 1.0
    assert sig.descripteurs("123 456")["part_majuscules"] == 0.0     # pas de lettre


@pytest.mark.parametrize("texte, attendu", [
    ("frais ?", sig.INDETERMINE),                                # sous le minimum de trois mots
    ("carte pas reçue", "fr"),                                   # trois mots : détection tentée
    ("Je n'ai toujours pas reçu ma nouvelle carte bancaire", "fr"),
    ("I ordered a new card three weeks ago and never received it", "en"),
])
def test_langue(texte, attendu):
    assert sig.langue(texte) == attendu


# ------------------------------------------------------------------ motif et familles
def test_toutes_les_familles_couvrent_les_modeles():
    labels = [m["label"] for m in json.loads(Path("data/business_response_models.json").read_text(encoding="utf-8"))]
    assert [l for l in labels if l not in sig.FAMILLES] == []


def test_motif_inconnu_echoue():
    with pytest.raises(KeyError):
        sig.famille_motif("Nouveau modèle non répertorié")


class FauxReranker:
    def __init__(self, scores): self._scores = scores
    def scores(self, requete, documents): return self._scores


def test_motif_et_couverture_seuil():
    docs = [("Carte non reçue", "…"), ("Erreur virement", "…")]
    assert sig.motif_et_couverture("x", FauxReranker([0.2, 0.9]), docs, None) == ("Erreur virement", 0.9)
    assert sig.motif_et_couverture("x", FauxReranker([0.2, 0.9]), docs, 0.5) == ("Erreur virement", 0.9)
    assert sig.motif_et_couverture("x", FauxReranker([0.2, 0.3]), docs, 0.5) == (sig.HORS_PERIMETRE, 0.3)


def test_client_reranker_lit_la_reponse(monkeypatch):
    class Reponse:
        status_code, headers = 200, {}
        def raise_for_status(self): pass
        def json(self): return {"results": [{"index": 1, "relevance_score": 0.8}, {"index": 0, "relevance_score": 0.1}]}
    appels = {}
    def faux_post(url, json, headers, timeout, verify):
        appels.update(url=url, json=json, headers=headers); return Reponse()
    monkeypatch.setattr(sig.requests, "post", faux_post)
    r = sig.Reranker(url="https://llm.interne/", cle="k")
    assert r.scores("q", ["a", "b"]) == [0.1, 0.8]                   # remis dans l'ordre des documents
    assert appels["url"] == "https://llm.interne/rerank"
    assert appels["headers"]["Authorization"] == "Bearer k"
    assert appels["json"]["top_n"] == 2


# ------------------------------------------------------------------ statistiques
def test_psi_nul_sur_distributions_identiques():
    p = {"a": 0.5, "b": 0.5}
    assert ref.psi(p, p) == pytest.approx(0.0)
    assert ref.psi(p, {"a": 0.9, "b": 0.1}) > 0.25


def test_centile():
    assert ref.centile([1, 2, 3, 4, 5], 50) == 3
    assert ref.centile([1, 2, 3, 4, 5], 95) == pytest.approx(4.8)


def test_seuil_hors_perimetre():
    lignes = ([{"label_large": "positif", "source": "mesure", "score_couverture": s} for s in range(10, 30)]
              + [{"label_large": "", "source": "abstentions", "score_couverture": s} for s in (1, 2, 25)])
    r = ref.fixer_seuil_hors_perimetre(lignes)
    assert r["seuil"] == pytest.approx(ref.centile(list(range(10, 30)), 5))
    assert r["abstentions_sous_le_seuil"] == 2


def test_client_reranker_reessaie_apres_429(monkeypatch):
    class Reponse:
        def __init__(self, code, headers=None): self.status_code, self.headers = code, headers or {}
        def raise_for_status(self):
            if self.status_code >= 400: raise sig.requests.HTTPError(str(self.status_code))
        def json(self): return {"results": [{"index": 0, "relevance_score": 0.5}]}
    reponses = iter([Reponse(429, {"Retry-After": "3"}), Reponse(200)])
    attentes = []
    monkeypatch.setattr(sig.requests, "post", lambda *a, **k: next(reponses))
    monkeypatch.setattr(sig.time, "sleep", attentes.append)
    assert sig.Reranker(url="u", cle="k").scores("q", ["a"]) == [0.5]
    assert attentes == [3.0]                                   # délai indiqué par le service respecté


def test_client_reranker_abandonne_apres_les_tentatives(monkeypatch):
    class Reponse:
        status_code, headers = 429, {}
        def raise_for_status(self): raise sig.requests.HTTPError("429")
    monkeypatch.setattr(sig.requests, "post", lambda *a, **k: Reponse())
    monkeypatch.setattr(sig.time, "sleep", lambda s: None)
    with pytest.raises(sig.requests.HTTPError):
        sig.Reranker(url="u", cle="k", tentatives=3).scores("q", ["a"])


# ------------------------------------------------------------------ embeddings
class _ReponseEmb:
    status_code, headers = 200, {}
    def __init__(self, donnees): self._d = donnees
    def raise_for_status(self): pass
    def json(self): return {"data": self._d}


def test_embedder_par_lots_et_dans_l_ordre(monkeypatch):
    appels = []
    def faux_post(url, json, headers, timeout, verify):
        appels.append(json["input"])
        # le service renvoie les vecteurs dans le désordre : le client doit les remettre en ordre
        return _ReponseEmb([{"index": i, "embedding": [float(len(t))]} for i, t in reversed(list(enumerate(json["input"])))])
    monkeypatch.setattr(sig.requests, "post", faux_post)
    e = sig.Embedder(url="u", cle="k", taille_lot=2)
    assert e.vecteurs(["a", "bb", "ccc", "dddd", "eeeee"]) == [[1.0], [2.0], [3.0], [4.0], [5.0]]
    assert appels == [["a", "bb"], ["ccc", "dddd"], ["eeeee"]]           # trois requêtes pour cinq textes


def test_embedder_nombre_de_vecteurs_incoherent(monkeypatch):
    monkeypatch.setattr(sig.requests, "post", lambda *a, **k: _ReponseEmb([{"index": 0, "embedding": [1.0]}]))
    with pytest.raises(ValueError):
        sig.Embedder(url="u", cle="k").vecteurs(["a", "b"])


def test_normaliser():
    assert sig.normaliser([3.0, 4.0]) == pytest.approx([0.6, 0.8])
    for invalide in ([0.0, 0.0], [1.0, float("nan")]):
        with pytest.raises(ValueError):
            sig.normaliser(invalide)


def test_intervalle_entre_requetes(monkeypatch):
    horloge, attentes = [100.0], []
    monkeypatch.setattr(sig.time, "monotonic", lambda: horloge[0])
    monkeypatch.setattr(sig.time, "sleep", lambda s: (attentes.append(round(s, 3)), horloge.__setitem__(0, horloge[0] + s)))
    sig._dernier_appel.clear()
    client = sig.Embedder(url="u-intervalle", cle="k", intervalle_min_s=6.5)
    sig._respecter_intervalle(client)                     # premier appel : aucune attente
    horloge[0] += 2.0
    sig._respecter_intervalle(client)                     # 2 s plus tard : attendre 4,5 s
    assert attentes == [4.5]

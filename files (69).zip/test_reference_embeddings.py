"""Tests du choix de modèle et du seuil de dérive des embeddings."""
import numpy as np
import pytest

import calculer_reference_embeddings as ref


def test_evaluer_deux_groupes_parfaits():
    v = np.array([[1, 0], [0.99, 0.14], [0, 1], [0.14, 0.99]], dtype=float)
    v /= np.linalg.norm(v, axis=1, keepdims=True)
    e = ref.evaluer(v, ["a", "a", "b", "b"])
    assert e["accord_plus_proche_voisine"] == 1.0
    assert e["hasard"] == 0.5
    assert e["gain_sur_le_hasard"] == 0.5


def test_verdict():
    evals = {"bon": {"gain_sur_le_hasard": 0.20}, "faible": {"gain_sur_le_hasard": 0.01}}
    assert ref.verdict(evals, "bon")["justifie"]
    assert not ref.verdict(evals, "faible")["justifie"]
    proches = {"a": {"gain_sur_le_hasard": 0.20}, "b": {"gain_sur_le_hasard": 0.18}}
    assert not ref.verdict(proches, "a")["justifie"]                   # avance insuffisante


def test_bruit_decroit_avec_la_taille_de_fenetre():
    v = np.random.default_rng(0).normal(size=(200, 16))
    v /= np.linalg.norm(v, axis=1, keepdims=True)
    petites = np.percentile(ref.distances_fenetres(v, 40, 500, 1), 95)
    grandes = np.percentile(ref.distances_fenetres(v, 400, 500, 1), 95)
    assert grandes < petites
    assert petites / grandes == pytest.approx(np.sqrt(10), rel=0.2)   # bruit en 1/racine(n)


def test_dimensions_heterogenes_refusees():
    with pytest.raises(ValueError):
        ref.matrice_normalisee({"a": [1.0, 0.0], "b": [1.0, 0.0, 0.0]}, ["a", "b"])

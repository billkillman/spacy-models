"""NUM-122 — Choisir le modèle d'embedding et calculer la référence de dérive.

Le script :

    1. calcule les embeddings des réclamations du pilote pour chaque modèle candidat ;
    2. compare les modèles : lequel place côte à côte les réclamations d'une même famille ?
    3. fige le modèle retenu, avec une empreinte qui détectera tout changement silencieux ;
    4. calcule la référence (vecteurs normalisés) et le seuil de dérive des centroïdes.

La comparaison des modèles
--------------------------
Pour chaque réclamation, on cherche sa plus proche voisine : sont-elles de la même famille ?
La part de réponses positives est comparée au **hasard** — la probabilité que deux
réclamations tirées au sort soient de la même famille. Seul l'écart au hasard a un sens.

Les familles viennent du reranker (NUM-109) : faute d'étiquettes métier, la mesure est une
**cohérence avec le reranker**, pas une vérité. Elle est valable pour comparer des modèles,
jugés sur les mêmes étiquettes ; elle ne dit pas qu'un modèle est « juste ».

Le seuil de dérive
------------------
Arize compare le centroïde des vecteurs d'une fenêtre de production à celui de la référence,
par distance euclidienne. Le script simule des fenêtres de la taille attendue, tirées dans la
référence, et place le seuil au 95e centile de leur distance au centroïde de référence.
Les vecteurs sont **normalisés** : ce sont exactement ceux-là qu'il faudra envoyer à Arize.

Usage
-----
    python calculer_reference_embeddings.py --jeu jeu_jugements --reference reference_signaux
    python calculer_reference_embeddings.py --jeu jeu_jugements --reference reference_signaux \\
        --modeles bge-m3 --taille-fenetre 100

Variables d'environnement : LLM_API_URL, LLM_API_KEY, CA_BUNDLE ; EMBEDDING_PATH (défaut /embeddings).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import os
import statistics
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

import numpy as np

import signaux_entree as sig
from calculer_reference import centile, lire_jeu

MODELES_CANDIDATS = ("bge-m3", "bge-large-en-v1.5")
MODELE_RETENU = "bge-m3"
TAILLE_FENETRE = 100
TAILLES_SENSIBILITE = (40, 100, 200, 400)
TIRAGES = 2000
CENTILE_SEUIL = 95
GRAINE = 42
INTERVALLE_S = 6.5          # environ une requête toutes les six secondes par modèle
GAIN_MINIMAL = 0.05         # avance minimale du modèle retenu sur les autres, au-delà du hasard


# =============================================================================
# Calcul des embeddings, avec reprise
# =============================================================================

def cle_cache(modele: str, texte: str) -> str:
    return hashlib.sha256(f"{modele}|{texte}".encode()).hexdigest()


def embeddings_avec_cache(embedder: sig.Embedder, lignes: list[dict], cache_chemin: Path) -> dict[str, list[float]]:
    """Embeddings bruts de chaque réclamation ; les résultats obtenus sont conservés.

    Une relance ne renvoie au service que les textes manquants.
    """
    cache = {}
    if cache_chemin.exists():
        for ligne in cache_chemin.read_text(encoding="utf-8").splitlines():
            if ligne.strip():
                entree = json.loads(ligne)
                cache[entree["cle"]] = entree["vecteur"]

    manquants = [l for l in lignes if cle_cache(embedder.modele, l["texte"]) not in cache]
    deja = len(lignes) - len(manquants)
    if manquants:
        appels = -(-len(manquants) // embedder.taille_lot)
        print(f"    {embedder.modele} : {len(manquants)} texte(s) à calculer en {appels} requête(s)"
              + (f" — {deja} déjà obtenu(s)" if deja else ""))
        with cache_chemin.open("a", encoding="utf-8") as journal:
            for debut in range(0, len(manquants), embedder.taille_lot):
                lot = manquants[debut: debut + embedder.taille_lot]
                vecteurs = embedder.vecteurs([l["texte"] for l in lot])
                for ligne, vecteur in zip(lot, vecteurs):
                    cle = cle_cache(embedder.modele, ligne["texte"])
                    cache[cle] = vecteur
                    journal.write(json.dumps({"cle": cle, "vecteur": vecteur}) + "\n")
                journal.flush()
    else:
        print(f"    {embedder.modele} : {deja} texte(s) déjà obtenu(s), aucune requête")
    return {l["claim_id"]: cache[cle_cache(embedder.modele, l["texte"])] for l in lignes}


def matrice_normalisee(bruts: dict[str, list[float]], ids: list[str]) -> np.ndarray:
    """Vecteurs normalisés, dans l'ordre des identifiants ; dimension constante vérifiée."""
    dimensions = {len(bruts[i]) for i in ids}
    if len(dimensions) != 1:
        raise ValueError(f"dimensions hétérogènes : {sorted(dimensions)}")
    return np.array([sig.normaliser(bruts[i]) for i in ids])


# =============================================================================
# Comparaison des modèles
# =============================================================================

def evaluer(vecteurs: np.ndarray, familles: list[str]) -> dict:
    """Part des réclamations dont la plus proche voisine est de la même famille, et hasard."""
    similarites = vecteurs @ vecteurs.T
    np.fill_diagonal(similarites, -np.inf)               # une réclamation n'est pas sa propre voisine
    voisines = similarites.argmax(axis=1)
    accord = float(np.mean([familles[i] == familles[j] for i, j in enumerate(voisines)]))
    proportions = np.array(list(Counter(familles).values())) / len(familles)
    hasard = float(np.sum(proportions ** 2))
    return {"accord_plus_proche_voisine": round(accord, 4), "hasard": round(hasard, 4),
            "gain_sur_le_hasard": round(accord - hasard, 4)}


def verdict(evaluations: dict, retenu: str) -> dict:
    gain = evaluations[retenu]["gain_sur_le_hasard"]
    autres = {m: e["gain_sur_le_hasard"] for m, e in evaluations.items() if m != retenu}
    meilleur_autre = max(autres.values()) if autres else None
    justifie = gain > GAIN_MINIMAL and (meilleur_autre is None or gain - meilleur_autre >= GAIN_MINIMAL)
    return {"modele_retenu": retenu, "justifie": justifie,
            "avance_sur_le_meilleur_autre": round(gain - meilleur_autre, 4) if autres else None,
            "regle": f"gain sur le hasard > {GAIN_MINIMAL}, et avance d'au moins {GAIN_MINIMAL} sur les autres"}


# =============================================================================
# Seuil de dérive
# =============================================================================

def distances_fenetres(vecteurs: np.ndarray, taille: int, tirages: int, graine: int) -> np.ndarray:
    """Distance entre le centroïde de fenêtres tirées dans la référence et le centroïde de référence."""
    generateur = np.random.default_rng(graine)
    centre = vecteurs.mean(axis=0)
    indices = generateur.integers(0, len(vecteurs), size=(tirages, taille))
    centres_fenetres = vecteurs[indices].mean(axis=1)
    return np.linalg.norm(centres_fenetres - centre, axis=1)


# =============================================================================
# Pilotage
# =============================================================================

def lire_familles(dossier: Path) -> dict[str, str]:
    chemin = dossier / "reference_signaux.csv"
    if not chemin.exists():
        raise SystemExit(f"Référence de NUM-109 introuvable : {chemin}")
    with chemin.open(encoding="utf-8", newline="") as flux:
        return {l["claim_id"]: l["famille"] for l in csv.DictReader(flux) if l.get("famille")}


def main() -> int:
    parser = argparse.ArgumentParser(description="NUM-122 — modèle d'embedding et référence de dérive.")
    parser.add_argument("--jeu", default="jeu_jugements")
    parser.add_argument("--reference", default="reference_signaux", help="dossier produit en NUM-109")
    parser.add_argument("--modeles", default=",".join(MODELES_CANDIDATS),
                        help="modèles comparés, séparés par des virgules")
    parser.add_argument("--retenu", default=MODELE_RETENU)
    parser.add_argument("--taille-fenetre", type=int, default=TAILLE_FENETRE)
    parser.add_argument("--taille-lot", type=int, default=32, help="textes par requête")
    parser.add_argument("--intervalle", type=float, default=INTERVALLE_S,
                        help=f"secondes minimum entre deux requêtes à un même modèle (défaut : {INTERVALLE_S})")
    parser.add_argument("--sortie", default="reference_embeddings")
    args = parser.parse_args()
    logging.basicConfig(level=logging.WARNING, format="    %(message)s")
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    modeles = [m.strip() for m in args.modeles.split(",") if m.strip()]
    if args.retenu not in modeles:
        raise SystemExit(f"Le modèle retenu ({args.retenu}) doit figurer parmi les modèles comparés.")

    lignes = lire_jeu(Path(args.jeu))
    familles = lire_familles(Path(args.reference))
    lignes = [l for l in lignes if l["claim_id"] in familles]
    ids = [l["claim_id"] for l in lignes]
    etiquettes = [familles[i] for i in ids]
    print(f"\n  {len(lignes)} réclamations, {len(set(etiquettes))} familles")

    sortie = Path(args.sortie)
    sortie.mkdir(parents=True, exist_ok=True)

    def client(modele: str) -> sig.Embedder:
        return sig.Embedder(url=os.environ["LLM_API_URL"], cle=os.environ["LLM_API_KEY"], modele=modele,
                            chemin=os.getenv("EMBEDDING_PATH", "/embeddings"),
                            verification=os.getenv("CA_BUNDLE") or True,
                            intervalle_min_s=args.intervalle, taille_lot=args.taille_lot)

    print("\n  Calcul des embeddings…")
    matrices, evaluations = {}, {}
    for modele in modeles:
        bruts = embeddings_avec_cache(client(modele), lignes, sortie / "cache_embeddings.jsonl")
        matrices[modele] = matrice_normalisee(bruts, ids)
        evaluations[modele] = evaluer(matrices[modele], etiquettes)
        evaluations[modele]["dimension"] = int(matrices[modele].shape[1])

    decision = verdict(evaluations, args.retenu)
    empreinte = sig.empreinte_modele(client(args.retenu))

    reference = matrices[args.retenu]
    sensibilite = {}
    for taille in TAILLES_SENSIBILITE:
        d = distances_fenetres(reference, taille, TIRAGES, GRAINE)
        sensibilite[taille] = {"mediane": round(float(np.median(d)), 5),
                               f"seuil_p{CENTILE_SEUIL}": round(float(np.percentile(d, CENTILE_SEUIL)), 5)}
    distances = distances_fenetres(reference, args.taille_fenetre, TIRAGES, GRAINE)
    seuil = float(np.percentile(distances, CENTILE_SEUIL))

    with (sortie / "vecteurs_reference.jsonl").open("w", encoding="utf-8") as flux:
        sources = {l["claim_id"]: l["source"] for l in lignes}
        for i, cid in enumerate(ids):
            flux.write(json.dumps({"claim_id": cid, "source": sources[cid], "famille": etiquettes[i],
                                   "vecteur": [round(x, 6) for x in reference[i].tolist()]}) + "\n")

    contenu = (sortie / "vecteurs_reference.jsonl").read_bytes()
    manifeste = {
        "version": f"{datetime.now():%Y%m%d}-{hashlib.sha256(contenu).hexdigest()[:8]}",
        "genere_le": datetime.now().isoformat(timespec="seconds"),
        "modele": {"nom": args.retenu, "chemin": os.getenv("EMBEDDING_PATH", "/embeddings"),
                   "dimension": evaluations[args.retenu]["dimension"], "empreinte": empreinte,
                   "phrase_empreinte": sig.PHRASE_EMPREINTE, "normalisation": "L2 (longueur 1)"},
        "comparaison_des_modeles": evaluations,
        "decision": decision,
        "reference": {"reclamations": len(ids), "fichier": "vecteurs_reference.jsonl"},
        "seuil_derive": {"distance_euclidienne_des_centroides": round(seuil, 5),
                         "taille_fenetre": args.taille_fenetre, "tirages": TIRAGES,
                         "centile": CENTILE_SEUIL, "bruit_median": round(float(np.median(distances)), 5)},
        "sensibilite_a_la_taille_de_fenetre": sensibilite,
        "limites": [
            "Comparaison des modèles jugée sur les familles du reranker : une cohérence, pas une vérité.",
            "Seuil à confirmer sur la distance calculée par Arize (NUM-125).",
            "Changer de modèle ou de normalisation impose de recalculer cette référence.",
        ],
    }
    (sortie / "seuils_embeddings.json").write_text(json.dumps(manifeste, ensure_ascii=False, indent=2),
                                                  encoding="utf-8")
    afficher(manifeste)
    return 0 if decision["justifie"] else 1


def afficher(m: dict) -> None:
    print(f"\n  Comparaison des modèles — la plus proche voisine est-elle de la même famille ?")
    print(f"    {'modèle':<22} {'dimension':>9} {'accord':>8} {'hasard':>8} {'gain':>8}")
    for modele, e in m["comparaison_des_modeles"].items():
        marque = "  ← retenu" if modele == m["decision"]["modele_retenu"] else ""
        print(f"    {modele:<22} {e['dimension']:>9} {e['accord_plus_proche_voisine']:>8.1%} "
              f"{e['hasard']:>8.1%} {e['gain_sur_le_hasard']:>+8.1%}{marque}")
    d = m["decision"]
    print(f"\n  Choix {'JUSTIFIÉ' if d['justifie'] else 'NON DÉMONTRÉ'} ({d['regle']})")
    if not d["justifie"]:
        print("    Le modèle retenu ne se distingue pas assez : examiner avant de figer ce choix.")
    print(f"\n  Modèle figé : {m['modele']['nom']} — dimension {m['modele']['dimension']}, "
          f"empreinte {m['modele']['empreinte']}")
    s = m["seuil_derive"]
    print(f"\n  Seuil de dérive (fenêtres de {s['taille_fenetre']}) : {s['distance_euclidienne_des_centroides']:.4f}"
          f"   (bruit médian {s['bruit_median']:.4f})")
    print(f"    {'fenêtre':>8} {'médiane':>9} {'seuil':>9}")
    for taille, v in m["sensibilite_a_la_taille_de_fenetre"].items():
        print(f"    {taille:>8} {v['mediane']:>9.4f} {v[f'seuil_p{CENTILE_SEUIL}']:>9.4f}")
    print(f"\n  Référence {m['version']} : vecteurs_reference.jsonl, seuils_embeddings.json\n")


if __name__ == "__main__":
    sys.exit(main())

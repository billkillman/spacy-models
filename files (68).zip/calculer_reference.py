"""NUM-109 — Calculer la référence des signaux d'entrée et fixer les seuils des moniteurs.

Tout signal se juge par rapport à une référence ; celle du pilote est petite, et un seuil
fixé au jugé déclencherait sur le simple bruit d'échantillonnage. Le script :

    1. calcule les trois signaux sur chaque réclamation du pilote ;
    2. fixe le seuil « hors périmètre » du reranker ;
    3. mesure le bruit naturel de chaque indicateur surveillé, et en déduit les seuils ;
    4. écrit la référence, les seuils et leur justification.

Le seuil « hors périmètre »
---------------------------
Placé au 5e centile des scores des réclamations **dont la réponse a été jugée pertinente** :
ces réclamations sont couvertes à coup sûr, et au plus 5 % d'entre elles seront classées
hors périmètre à tort. On ne le fixe pas sur les abstentions : il n'y en a qu'une poignée,
trop peu pour fonder un seuil. Elles servent en revanche de contrôle : un bon seuil doit
en placer la plupart en dessous.

Le bruit naturel
----------------
Arize compare une **fenêtre de production** à la référence complète. Le script simule donc
un grand nombre de fenêtres de la taille attendue en production, tirées au hasard dans la
référence, et mesure à chaque fois l'écart avec la référence. Le seuil est placé au 95e
centile de ces écarts : sur des données sans dérive, une fenêtre sur vingt au plus le
dépasserait. La taille de fenêtre compte : une fenêtre de 40 réclamations fluctue bien
plus qu'une de 400. Elle doit donc correspondre au volume réel d'une fenêtre de moniteur.

Usage
-----
    python calculer_reference.py --jeu jeu_jugements
    python calculer_reference.py --jeu jeu_jugements --taille-fenetre 40
    python calculer_reference.py --jeu jeu_jugements --sans-reranker
    python calculer_reference.py --jeu jeu_jugements --pause 3     # service très limité

En cas d'interruption, relancer la même commande : le calcul reprend où il s'était arrêté.

Variables d'environnement (les mêmes que l'API) : LLM_API_URL, LLM_API_KEY, CA_BUNDLE ;
et RERANK_MODEL (défaut bge-reranker-v2-m3), RERANK_PATH (défaut /rerank).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import math
import os
import random
import statistics
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

import signaux_entree as sig

TAILLE_FENETRE = 100     # volume d'une fenêtre de moniteur : voir la sensibilité dans le rapport
TAILLES_SENSIBILITE = (40, 100, 200, 400)
SEUIL_PSI_CONVENTIONNEL = 0.25
TIRAGES = 2000
CENTILE_SEUIL = 95
CENTILE_HORS_PERIMETRE = 5
GRAINE = 42
EPSILON = 1e-4           # évite ln(0) quand une catégorie est absente d'une fenêtre
NB_TRANCHES = 10

FICHIERS = {"calibrage": "recla_jugements_calibrage.csv", "mesure": "recla_jugements_mesure.csv",
            "abstentions": "recla_abstentions.csv"}


# =============================================================================
# Outils statistiques
# =============================================================================

def centile(valeurs: list[float], q: float) -> float:
    """Centile par interpolation linéaire."""
    ordonnees = sorted(valeurs)
    if not ordonnees:
        return float("nan")
    rang = (len(ordonnees) - 1) * q / 100
    bas, haut = math.floor(rang), math.ceil(rang)
    return ordonnees[bas] + (ordonnees[haut] - ordonnees[bas]) * (rang - bas)


def psi(reference: dict, fenetre: dict) -> float:
    """Indice de stabilité de population entre deux distributions (proportions par catégorie)."""
    total = 0.0
    for categorie in set(reference) | set(fenetre):
        p = max(reference.get(categorie, 0.0), EPSILON)
        q = max(fenetre.get(categorie, 0.0), EPSILON)
        total += (q - p) * math.log(q / p)
    return total


def proportions(valeurs: list) -> dict:
    compte = Counter(valeurs)
    return {k: n / len(valeurs) for k, n in compte.items()}


def en_tranches(valeurs: list[float], bornes: list[float]) -> list[int]:
    """Numéro de tranche de chaque valeur ; les bornes viennent des centiles de la référence."""
    return [sum(v > b for b in bornes) for v in valeurs]


def bornes_quantiles(valeurs: list[float]) -> list[float]:
    return sorted({centile(valeurs, 100 * k / NB_TRANCHES) for k in range(1, NB_TRANCHES)})


def auc(positifs: list[float], negatifs: list[float]) -> float | None:
    """Probabilité qu'une réclamation couverte ait un score supérieur à une abstention."""
    if not positifs or not negatifs:
        return None
    gagnes = sum((p > n) + 0.5 * (p == n) for p in positifs for n in negatifs)
    return gagnes / (len(positifs) * len(negatifs))


# =============================================================================
# Étapes
# =============================================================================

def lire_jeu(dossier: Path) -> list[dict]:
    lignes = []
    for source, nom in FICHIERS.items():
        chemin = dossier / nom
        if not chemin.exists():
            if source == "abstentions":
                continue
            raise SystemExit(f"Fichier manquant : {chemin}")
        with chemin.open(encoding="utf-8", newline="") as flux:
            for ligne in csv.DictReader(flux):
                lignes.append({"claim_id": ligne["claim_id"], "source": source,
                               "label_large": ligne.get("label_large", ""), "texte": ligne["claim_verbatim"]})
    return lignes


def cle_cache(texte: str, reranker) -> str:
    """Identifie un résultat : même texte, même reranker. Un changement de l'un l'invalide."""
    return hashlib.sha256(f"{reranker.modele}|{reranker.chemin}|{texte}".encode()).hexdigest()


def lire_cache(chemin: Path) -> dict:
    if not chemin.exists():
        return {}
    cache = {}
    for ligne in chemin.read_text(encoding="utf-8").splitlines():
        if ligne.strip():
            entree = json.loads(ligne)
            cache[entree["cle"]] = entree
    return cache


def calculer_signaux(lignes: list[dict], reranker, documents, cache_chemin: Path, pause_s: float) -> None:
    """Calcule les signaux ; chaque résultat du reranker est mémorisé dès qu'il est obtenu.

    Si le calcul s'interrompt (limite de débit, coupure), une relance reprend là où il
    s'était arrêté : les réclamations déjà traitées ne sont pas renvoyées au service.
    """
    cache = lire_cache(cache_chemin) if reranker is not None else {}
    if cache:
        print(f"    reprise : {len(cache)} résultat(s) déjà obtenu(s)")
    appels = 0
    with (cache_chemin.open("a", encoding="utf-8") if reranker is not None else open(os.devnull, "w")) as journal:
        for rang, ligne in enumerate(lignes, start=1):
            ligne.update(sig.descripteurs(ligne["texte"]))
            if reranker is not None:
                cle = cle_cache(ligne["texte"], reranker)
                if cle not in cache:
                    if appels and pause_s:
                        time.sleep(pause_s)              # espace les appels pour ménager le service
                    motif, couverture = sig.motif_et_couverture(ligne["texte"], reranker, documents, None)
                    appels += 1
                    cache[cle] = {"cle": cle, "motif_premier": motif, "score_couverture": couverture}
                    journal.write(json.dumps(cache[cle], ensure_ascii=False) + "\n")
                    journal.flush()
                ligne["motif_premier"] = cache[cle]["motif_premier"]
                ligne["score_couverture"] = cache[cle]["score_couverture"]
            if rang % 10 == 0 or rang == len(lignes):
                print(f"    {rang}/{len(lignes)} réclamations traitées ({appels} appel(s) au reranker)")


def fixer_seuil_hors_perimetre(lignes: list[dict]) -> dict:
    couvertes = [l["score_couverture"] for l in lignes if l["label_large"] == "positif"]
    abstentions = [l["score_couverture"] for l in lignes if l["source"] == "abstentions"]
    seuil = centile(couvertes, CENTILE_HORS_PERIMETRE)
    return {
        "seuil": round(seuil, 6),
        "regle": f"{CENTILE_HORS_PERIMETRE}e centile des scores des réclamations jugées pertinentes",
        "reclamations_couvertes": len(couvertes),
        "abstentions": len(abstentions),
        "abstentions_sous_le_seuil": sum(a < seuil for a in abstentions),
        "auc_couvertes_contre_abstentions": round(auc(couvertes, abstentions), 3) if abstentions else None,
    }


def simuler_fenetres(lignes: list[dict], taille: int, avec_reranker: bool) -> dict:
    """Écart entre des fenêtres tirées dans la référence et la référence elle-même."""
    tirage = random.Random(GRAINE)
    n = len(lignes)
    ref_motifs = proportions([l["motif"] for l in lignes]) if avec_reranker else None
    ref_familles = proportions([l["famille"] for l in lignes]) if avec_reranker else None
    numeriques = ["longueur_mots", "part_majuscules"] + (["score_couverture"] if avec_reranker else [])
    bornes = {c: bornes_quantiles([l[c] for l in lignes]) for c in numeriques}
    ref_tranches = {c: proportions(en_tranches([l[c] for l in lignes], bornes[c])) for c in numeriques}

    mesures = {"psi_familles": [], "psi_motifs": [], "part_encodage_suspect": [], "part_hors_perimetre": []}
    mesures.update({f"psi_{c}": [] for c in numeriques})
    for _ in range(TIRAGES):
        fenetre = [lignes[tirage.randrange(n)] for _ in range(taille)]
        mesures["part_encodage_suspect"].append(sum(l["encodage_suspect"] == "oui" for l in fenetre) / taille)
        if avec_reranker:
            motifs = [l["motif"] for l in fenetre]
            mesures["psi_motifs"].append(psi(ref_motifs, proportions(motifs)))
            mesures["psi_familles"].append(psi(ref_familles, proportions([l["famille"] for l in fenetre])))
            mesures["part_hors_perimetre"].append(motifs.count(sig.HORS_PERIMETRE) / taille)
        for c in numeriques:
            mesures[f"psi_{c}"].append(psi(ref_tranches[c], proportions(en_tranches([l[c] for l in fenetre], bornes[c]))))
    return {k: v for k, v in mesures.items() if v}


def seuils_moniteurs(lignes: list[dict], bruit: dict, avec_reranker: bool) -> dict:
    """Seuils des moniteurs de NUM-115 et NUM-116, avec leur justification."""
    def bloc(nom, niveau_reference, alertant, moniteur):
        valeurs = bruit[nom]
        return {"moniteur": moniteur, "alertant": alertant,
                "niveau_de_reference": round(niveau_reference, 4) if niveau_reference is not None else None,
                "bruit_median": round(statistics.median(valeurs), 4),
                f"seuil_p{CENTILE_SEUIL}": round(centile(valeurs, CENTILE_SEUIL), 4)}

    n = len(lignes)
    seuils = {
        "part_encodage_suspect": bloc("part_encodage_suspect",
                                      sum(l["encodage_suspect"] == "oui" for l in lignes) / n, True, "NUM-115"),
        "nouvelle_langue": {"moniteur": "NUM-115", "alertant": True,
                            "regle": "toute valeur absente de la référence (moniteur « nouvelles valeurs »)",
                            "langues_de_reference": dict(Counter(l["langue"] for l in lignes))},
        "psi_longueur_mots": bloc("psi_longueur_mots", None, False, "NUM-115 (affiché)"),
        "psi_part_majuscules": bloc("psi_part_majuscules", None, False, "NUM-115 (affiché)"),
    }
    if avec_reranker:
        seuils["psi_familles"] = bloc("psi_familles", None, True, "NUM-116")
        seuils["psi_motifs"] = bloc("psi_motifs", None, False, "NUM-116 (affiché)")
        seuils["part_hors_perimetre"] = bloc(
            "part_hors_perimetre", sum(l["motif"] == sig.HORS_PERIMETRE for l in lignes) / n, True, "NUM-116")
        seuils["psi_score_couverture"] = bloc("psi_score_couverture", None, False, "NUM-116 (affiché)")
    return seuils


# =============================================================================
# Pilotage
# =============================================================================

def main() -> int:
    parser = argparse.ArgumentParser(description="NUM-109 — référence des signaux et seuils des moniteurs.")
    parser.add_argument("--jeu", default="jeu_jugements", help="dossier produit en NUM-14")
    parser.add_argument("--modeles", default="data/business_response_models.json")
    parser.add_argument("--taille-fenetre", type=int, default=TAILLE_FENETRE,
                        help=f"réclamations par fenêtre de moniteur en production (défaut : {TAILLE_FENETRE})")
    parser.add_argument("--sans-reranker", action="store_true",
                        help="descripteurs seuls, si le reranker n'est pas encore accessible")
    parser.add_argument("--pause", type=float, default=1.0,
                        help="secondes entre deux appels au reranker (défaut : 1)")
    parser.add_argument("--sortie", default="reference_signaux")
    args = parser.parse_args()
    logging.basicConfig(level=logging.WARNING, format="    %(message)s")

    lignes = lire_jeu(Path(args.jeu))
    print(f"\n  {len(lignes)} réclamations lues ({dict(Counter(l['source'] for l in lignes))})")

    reranker, documents = None, None
    if not args.sans_reranker:
        documents = sig.documents_modeles(Path(args.modeles))
        sans_famille = [libelle for libelle, _ in documents if libelle not in sig.FAMILLES]
        if sans_famille:
            raise SystemExit(f"Modèles de réponse sans famille : {sans_famille}. Compléter FAMILLES.")
        reranker = sig.Reranker(
            url=os.environ["LLM_API_URL"], cle=os.environ["LLM_API_KEY"],
            modele=os.getenv("RERANK_MODEL", "bge-reranker-v2-m3"), chemin=os.getenv("RERANK_PATH", "/rerank"),
            verification=os.getenv("CA_BUNDLE") or True)
        print(f"  reranker : {reranker.modele} — {len(documents)} modèles de réponse")

    sortie = Path(args.sortie)
    sortie.mkdir(parents=True, exist_ok=True)
    print("\n  Calcul des signaux…")
    calculer_signaux(lignes, reranker, documents, sortie / "cache_reranker.jsonl", args.pause)

    hors_perimetre = None
    if reranker is not None:
        hors_perimetre = fixer_seuil_hors_perimetre(lignes)
        for l in lignes:
            l["motif"] = sig.HORS_PERIMETRE if l["score_couverture"] < hors_perimetre["seuil"] else l["motif_premier"]
            l["famille"] = sig.famille_motif(l["motif"])

    bruit = simuler_fenetres(lignes, args.taille_fenetre, reranker is not None)
    sensibilite = {}
    for taille in TAILLES_SENSIBILITE:
        b = simuler_fenetres(lignes, taille, reranker is not None)
        sensibilite[taille] = {k: round(centile(v, CENTILE_SEUIL), 4) for k, v in b.items()
                               if k in ("psi_familles", "psi_motifs", "part_hors_perimetre", "part_encodage_suspect")}
    seuils = seuils_moniteurs(lignes, bruit, reranker is not None)

    colonnes = ["claim_id", "source", "label_large", "longueur_mots", "part_majuscules", "nb_exclamations",
                "langue", "encodage_suspect", "nb_jetons_anonymisation"]
    if reranker is not None:
        colonnes += ["motif", "famille", "score_couverture"]
    with (sortie / "reference_signaux.csv").open("w", encoding="utf-8", newline="") as flux:
        ecrivain = csv.DictWriter(flux, fieldnames=colonnes, extrasaction="ignore")
        ecrivain.writeheader()
        ecrivain.writerows(lignes)

    contenu = (sortie / "reference_signaux.csv").read_bytes()
    manifeste = {
        "version": f"{datetime.now():%Y%m%d}-{hashlib.sha256(contenu).hexdigest()[:8]}",
        "genere_le": datetime.now().isoformat(timespec="seconds"),
        "reclamations": len(lignes),
        "reranker": ({"modele": reranker.modele, "chemin": reranker.chemin} if reranker
                     else "non utilisé — signaux 2 et 3 à calculer"),
        "seuil_hors_perimetre": hors_perimetre,
        "parametres": {"taille_fenetre": args.taille_fenetre, "tirages": TIRAGES, "centile_seuil": CENTILE_SEUIL,
                       "graine": GRAINE, "tranches_numeriques": NB_TRANCHES},
        "seuils_moniteurs": seuils,
        "sensibilite_a_la_taille_de_fenetre": sensibilite,
        "repartition_des_motifs": dict(Counter(l["motif"] for l in lignes)) if reranker else None,
        "limites": [
            "Référence petite : seuils indicatifs, à confirmer sur les valeurs calculées par Arize (NUM-114).",
            "Le calcul de l'indice de stabilité par Arize peut différer (découpage en tranches) : comparer.",
            "Le seuil hors périmètre dépend du reranker : le changer impose de recalculer la référence.",
        ],
    }
    (sortie / "seuils_signaux.json").write_text(json.dumps(manifeste, ensure_ascii=False, indent=2), encoding="utf-8")
    afficher(manifeste, lignes)
    return 0


def afficher(m: dict, lignes: list[dict]) -> None:
    print(f"\n  Référence {m['version']} — {m['reclamations']} réclamations")
    hp = m["seuil_hors_perimetre"]
    if hp:
        print(f"\n  Seuil « hors périmètre » : {hp['seuil']}  ({hp['regle']})")
        print(f"    abstentions sous le seuil : {hp['abstentions_sous_le_seuil']}/{hp['abstentions']}"
              f"   |   AUC couvertes / abstentions : {hp['auc_couvertes_contre_abstentions']}")
        if hp["abstentions"] < 20:
            print(f"    (sur {hp['abstentions']} abstentions, ce contrôle est indicatif)")
    print(f"\n  Seuils des moniteurs — fenêtres de {m['parametres']['taille_fenetre']} réclamations, "
          f"{m['parametres']['tirages']} tirages")
    print(f"    {'indicateur':<24} {'moniteur':<20} {'référence':>10} {'bruit médian':>13} {'seuil':>9}")
    for nom, s in m["seuils_moniteurs"].items():
        if "regle" in s:
            print(f"    {nom:<24} {s['moniteur']:<20} {'':>10} {'':>13}   nouvelles valeurs "
                  f"(référence : {s['langues_de_reference']})")
            continue
        ref = "" if s["niveau_de_reference"] is None else f"{s['niveau_de_reference']:.3f}"
        print(f"    {nom:<24} {s['moniteur']:<20} {ref:>10} {s['bruit_median']:>13.3f} "
              f"{s[f'seuil_p{CENTILE_SEUIL}']:>9.3f}")
    sens = m["sensibilite_a_la_taille_de_fenetre"]
    if any("psi_familles" in v for v in sens.values()):
        print(f"\n  Sensibilité à la taille de fenêtre (seuils au {CENTILE_SEUIL}e centile)")
        print(f"    {'fenêtre':>8} {'familles':>10} {'motifs':>10} {'hors périmètre':>16}")
        for taille, v in sens.items():
            print(f"    {taille:>8} {v['psi_familles']:>10.2f} {v['psi_motifs']:>10.2f} {v['part_hors_perimetre']:>16.3f}")
        seuil_familles = m["seuils_moniteurs"]["psi_familles"][f"seuil_p{CENTILE_SEUIL}"]
        if seuil_familles > SEUIL_PSI_CONVENTIONNEL:
            print(f"\n  ATTENTION : avec des fenêtres de {m['parametres']['taille_fenetre']} réclamations, le bruit "
                  f"de la répartition par familles ({seuil_familles:.2f}) dépasse le seuil d'alerte habituel "
                  f"({SEUIL_PSI_CONVENTIONNEL}). Ce moniteur ne distinguerait pas une dérive du hasard : "
                  "agrandir les fenêtres.")
    if m["repartition_des_motifs"]:
        print("\n  Motifs de la référence (les plus fréquents) :")
        for motif, n in Counter(l["motif"] for l in lignes).most_common(6):
            print(f"    {n:>4}  {motif}")
    print("\n  Fichiers : reference_signaux.csv, seuils_signaux.json\n")


if __name__ == "__main__":
    sys.exit(main())

"""Calcul des signaux d'entrée des réclamations.

Ce module est la **source unique** du calcul des signaux. Il sert à deux moments :

    - au calcul de la référence, sur le corpus du pilote (NUM-109) ;
    - au calcul en production, pour chaque réclamation reçue (NUM-112).

Référence et production doivent être calculées exactement de la même façon : tout
écart de méthode apparaîtrait comme une dérive. Les signaux se calculent sur le texte
**anonymisé**, comme celui du corpus de référence.

Les trois signaux
-----------------
1. Descripteurs de surface — longueur, majuscules, exclamations, langue, encodage
   suspect, jetons d'anonymisation. Détectent les pannes d'intégration.
2. Motif estimé — le modèle de réponse que le reranker classe premier, ou
   ``hors périmètre`` si même le premier est peu pertinent.
3. Score de couverture — le score de ce modèle classé premier.
"""

from __future__ import annotations

import json
import logging
import random
import re
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional

import requests

logger = logging.getLogger(__name__)

#: Réponses qui justifient un nouvel essai : limite de débit, service momentanément indisponible.
CODES_A_REESSAYER = {429, 502, 503, 504}

HORS_PERIMETRE = "hors périmètre"
INDETERMINE = "indetermine"

#: Regroupement des 27 modèles de réponse en familles. Surveiller la répartition de 27
#: motifs exige de très grandes fenêtres : avec 40 réclamations, chaque motif ne compte
#: que 0 à 3 cas, et l'indice de dérive est dominé par le hasard. Huit familles
#: stabilisent l'indicateur. Table proposée par le Tech Lead, faute de métier disponible :
#: à relire. Un libellé absent fait échouer le calcul, pour qu'un nouveau modèle de
#: réponse impose de compléter la table.
FAMILLES = {
    "Tarification - Frais Facilité de caisse dépassée": "Tarification",
    "Tarification - Frais Rejet de prélèvement": "Tarification",
    "Tarification - Frais Chèque impayé": "Tarification",
    "Tarification - Frais incidents et irrégularités": "Tarification",
    "Tarification - Frais inconnus ou autres": "Tarification",
    "Tarification - Frais de succession": "Tarification",
    "Tarification - Frais tenue de compte": "Tarification",
    "Frais Esprit Libre": "Tarification",
    "Frais cotisation carte": "Tarification",
    "Carte non reçue": "Carte",
    "Impossibilité paiement ou retrait carte": "Carte",
    "Contestation décision banque": "Contestations",
    "Contestation paiement carte": "Contestations",
    "Contestation virement": "Contestations",
    "Contestation prélèvement": "Contestations",
    "Impossibilité émission virement": "Virements et bénéficiaires",
    "Erreur virement": "Virements et bénéficiaires",
    "Erreur ajout bénéficiaire": "Virements et bénéficiaires",
    "Conseiller non joignable": "Relation client",
    "Absence de réponse du conseiller": "Relation client",
    "Qualité service client": "Relation client",
    "Dysfonctionnement site web Ma Banque": "Canaux numériques",
    "Dysfonctionnement application Mes Comptes": "Canaux numériques",
    "Erreur accès relevés en ligne": "Canaux numériques",
    "Clôture de compte": "Compte et relevés",
    "Non réception relevés papier": "Compte et relevés",
    "Autres": "Autres",
    HORS_PERIMETRE: "Hors périmètre",
}


def famille_motif(motif: str) -> str:
    """Famille d'un motif. Échoue sur un libellé inconnu : la table doit être complétée."""
    try:
        return FAMILLES[motif]
    except KeyError:
        raise KeyError(f"Motif sans famille : « {motif} ». Compléter FAMILLES.") from None

#: En dessous, la langue n'est pas attribuée : sur trois mots, une détection est un pari.
LANGUE_MOTS_MIN = 3
LANGUE_CONFIANCE_MIN = 0.60

_MOT = re.compile(r"\w+", re.UNICODE)
_LETTRE = re.compile(r"[^\W\d_]", re.UNICODE)
_JETON = re.compile(r"\[[A-Z_]+\]")
# Caractères typiques d'un texte UTF-8 relu comme du Latin-1 (« Ã© » pour « é »),
# et caractère de remplacement laissé par un décodage raté.
_ENCODAGE_SUSPECT = re.compile(r"Ã[\u0080-\u00bf]|â€|Â[\u00a0-\u00bf]|\ufffd")


# =============================================================================
# Signal 1 — descripteurs de surface
# =============================================================================

@lru_cache(maxsize=1)
def _detecteur_langue():
    """Détecteur limité aux langues plausibles : plus rapide, et moins d'erreurs."""
    from lingua import Language, LanguageDetectorBuilder

    langues = [Language.FRENCH, Language.ENGLISH, Language.SPANISH, Language.GERMAN, Language.ITALIAN,
               Language.PORTUGUESE, Language.ARABIC, Language.DUTCH]
    return LanguageDetectorBuilder.from_languages(*langues).build()


def langue(texte: str) -> str:
    """Code de la langue (``fr``, ``en``…) ou ``indetermine`` si le texte ne permet pas de trancher."""
    texte_sans_jetons = _JETON.sub(" ", texte)
    if len(_MOT.findall(texte_sans_jetons)) < LANGUE_MOTS_MIN:
        return INDETERMINE
    meilleure = _detecteur_langue().compute_language_confidence_values(texte_sans_jetons)[0]
    if meilleure.value < LANGUE_CONFIANCE_MIN:
        return INDETERMINE
    return meilleure.language.iso_code_639_1.name.lower()


def descripteurs(texte: str) -> dict:
    """Descripteurs de surface d'une réclamation anonymisée."""
    texte = texte or ""
    lettres = _LETTRE.findall(texte)
    return {
        "longueur_mots": len(_MOT.findall(_JETON.sub(" ", texte))),
        "part_majuscules": round(sum(c.isupper() for c in lettres) / len(lettres), 4) if lettres else 0.0,
        "nb_exclamations": texte.count("!"),
        "langue": langue(texte),
        "encodage_suspect": "oui" if _ENCODAGE_SUSPECT.search(texte) else "non",
        "nb_jetons_anonymisation": len(_JETON.findall(texte)),
    }


# =============================================================================
# Signaux 2 et 3 — motif estimé et score de couverture
# =============================================================================

def documents_modeles(chemin: Path) -> list[tuple[str, str]]:
    """Les 27 modèles de réponse, sous la forme (libellé, texte soumis au reranker).

    Le texte réunit le libellé, les intitulés des options et leurs contenus : c'est ce
    qui décrit le mieux le périmètre couvert par chaque modèle.
    """
    modeles = json.loads(Path(chemin).read_text(encoding="utf-8"))
    documents = []
    for modele in modeles:
        parties = [modele["label"]]
        for reponse in modele.get("responses", []):
            parties += [reponse.get("option", ""), reponse.get("content", "")]
        documents.append((modele["label"], "\n".join(p for p in parties if p)))
    return documents


@dataclass(frozen=True)
class Reranker:
    """Client du service de reranking.

    Sa version est **figée** : changer de reranker, c'est changer de thermomètre. La
    référence devrait alors être recalculée.
    """

    url: str
    cle: str
    modele: str = "bge-reranker-v2-m3"
    chemin: str = "/rerank"
    verification: object = True
    delai_s: float = 30.0
    tentatives: int = 6
    attente_base_s: float = 2.0
    attente_max_s: float = 60.0

    def _attente(self, reponse, essai: int) -> float:
        """Délai avant le prochain essai.

        Le délai indiqué par le service (en-tête ``Retry-After``) est respecté en
        priorité. À défaut, l'attente double à chaque essai, avec une part aléatoire
        pour que des appels simultanés ne se relancent pas tous au même instant.
        """
        indique = reponse.headers.get("Retry-After", "")
        if indique.replace(".", "", 1).isdigit():
            return min(float(indique), self.attente_max_s)
        return min(self.attente_base_s * 2 ** essai + random.uniform(0, 1), self.attente_max_s)

    def scores(self, requete: str, documents: list[str]) -> list[float]:
        """Score de pertinence de chaque document pour la requête, dans l'ordre des documents.

        Sur une limite de débit ou une indisponibilité passagère, l'appel est
        réessayé ; au-delà du nombre de tentatives, l'erreur est levée.
        """
        for essai in range(self.tentatives):
            reponse = requests.post(
                f"{self.url.rstrip('/')}{self.chemin}",
                json={"model": self.modele, "query": requete, "documents": documents,
                      "top_n": len(documents), "return_documents": False},
                headers={"Authorization": f"Bearer {self.cle}"},
                timeout=self.delai_s,
                verify=self.verification,
            )
            if reponse.status_code in CODES_A_REESSAYER and essai < self.tentatives - 1:
                attente = self._attente(reponse, essai)
                logger.warning("Reranker : réponse %s, nouvel essai dans %.1f s (%d/%d)",
                               reponse.status_code, attente, essai + 1, self.tentatives - 1)
                time.sleep(attente)
                continue
            break
        reponse.raise_for_status()
        resultats = reponse.json().get("results", [])
        scores = [float("nan")] * len(documents)
        for r in resultats:
            scores[r["index"]] = float(r.get("relevance_score", r.get("score")))
        return scores


def motif_et_couverture(texte: str, reranker, documents: list[tuple[str, str]],
                        seuil_hors_perimetre: Optional[float]) -> tuple[str, float]:
    """Motif estimé et score de couverture d'une réclamation.

    Sans seuil (pendant le calcul de la référence, qui sert justement à le fixer),
    le motif est toujours celui du modèle classé premier.
    """
    scores = reranker.scores(texte, [texte_doc for _, texte_doc in documents])
    rang = max(range(len(scores)), key=lambda i: scores[i])
    couverture = scores[rang]
    if seuil_hors_perimetre is not None and couverture < seuil_hors_perimetre:
        return HORS_PERIMETRE, couverture
    return documents[rang][0], couverture

"""Tests du calcul des signaux d'entrée et des outils statistiques de la référence."""
import json
from pathlib import Path

import pytest

import calculer_reference as ref
import signaux_entree as sig


# ------------------------------------------------------------------ descripteurs
def test_descripteurs_de_base():
    d = sig.descripteurs("Bonjour, je conteste ces frais prélevés par [NOM] ! Merci !")
    assert d["nb_exclamations"] == 2
    assert d["nb_jetons_anonymisation"] == 1
    assert d["longueur_mots"] == 8             # le jeton [NOM] n'est pas compté comme un mot
    assert d["encodage_suspect"] == "non"
    assert d["langue"] == "fr"


def test_encodage_casse_detecte():
    assert sig.descripteurs("Le prÃ©lÃ¨vement nâ€™a pas eu lieu")["encodage_suspect"] == "oui"
    assert sig.descripteurs("Caractère perdu \ufffd ici")["encodage_suspect"] == "oui"


def test_majuscules():
    assert sig.descripteurs("JE SUIS EN COLERE")["part_majuscules"] == 1.0
    assert sig.descripteurs("123 456")["part_majuscules"] == 0.0     # pas de lettre


@pytest.mark.parametrize("texte, attendu", [
    ("frais ?", sig.INDETERMINE),                                # sous le minimum de trois mots
    ("carte pas reçue", "fr"),                                   # trois mots : détection tentée
    ("Je n'ai toujours pas reçu ma nouvelle carte bancaire", "fr"),
    ("I ordered a new card three weeks ago and never received it", "en"),
])
def test_langue(texte, attendu):
    assert sig.langue(texte) == attendu


# ------------------------------------------------------------------ motif et familles
def test_toutes_les_familles_couvrent_les_modeles():
    labels = [m["label"] for m in json.loads(Path("data/business_response_models.json").read_text(encoding="utf-8"))]
    assert [l for l in labels if l not in sig.FAMILLES] == []


def test_motif_inconnu_echoue():
    with pytest.raises(KeyError):
        sig.famille_motif("Nouveau modèle non répertorié")


class FauxReranker:
    def __init__(self, scores): self._scores = scores
    def scores(self, requete, documents): return self._scores


def test_motif_et_couverture_seuil():
    docs = [("Carte non reçue", "…"), ("Erreur virement", "…")]
    assert sig.motif_et_couverture("x", FauxReranker([0.2, 0.9]), docs, None) == ("Erreur virement", 0.9)
    assert sig.motif_et_couverture("x", FauxReranker([0.2, 0.9]), docs, 0.5) == ("Erreur virement", 0.9)
    assert sig.motif_et_couverture("x", FauxReranker([0.2, 0.3]), docs, 0.5) == (sig.HORS_PERIMETRE, 0.3)


def test_client_reranker_lit_la_reponse(monkeypatch):
    class Reponse:
        status_code, headers = 200, {}
        def raise_for_status(self): pass
        def json(self): return {"results": [{"index": 1, "relevance_score": 0.8}, {"index": 0, "relevance_score": 0.1}]}
    appels = {}
    def faux_post(url, json, headers, timeout, verify):
        appels.update(url=url, json=json, headers=headers); return Reponse()
    monkeypatch.setattr(sig.requests, "post", faux_post)
    r = sig.Reranker(url="https://llm.interne/", cle="k")
    assert r.scores("q", ["a", "b"]) == [0.1, 0.8]                   # remis dans l'ordre des documents
    assert appels["url"] == "https://llm.interne/rerank"
    assert appels["headers"]["Authorization"] == "Bearer k"
    assert appels["json"]["top_n"] == 2


# ------------------------------------------------------------------ statistiques
def test_psi_nul_sur_distributions_identiques():
    p = {"a": 0.5, "b": 0.5}
    assert ref.psi(p, p) == pytest.approx(0.0)
    assert ref.psi(p, {"a": 0.9, "b": 0.1}) > 0.25


def test_centile():
    assert ref.centile([1, 2, 3, 4, 5], 50) == 3
    assert ref.centile([1, 2, 3, 4, 5], 95) == pytest.approx(4.8)


def test_seuil_hors_perimetre():
    lignes = ([{"label_large": "positif", "source": "mesure", "score_couverture": s} for s in range(10, 30)]
              + [{"label_large": "", "source": "abstentions", "score_couverture": s} for s in (1, 2, 25)])
    r = ref.fixer_seuil_hors_perimetre(lignes)
    assert r["seuil"] == pytest.approx(ref.centile(list(range(10, 30)), 5))
    assert r["abstentions_sous_le_seuil"] == 2


def test_client_reranker_reessaie_apres_429(monkeypatch):
    class Reponse:
        def __init__(self, code, headers=None): self.status_code, self.headers = code, headers or {}
        def raise_for_status(self):
            if self.status_code >= 400: raise sig.requests.HTTPError(str(self.status_code))
        def json(self): return {"results": [{"index": 0, "relevance_score": 0.5}]}
    reponses = iter([Reponse(429, {"Retry-After": "3"}), Reponse(200)])
    attentes = []
    monkeypatch.setattr(sig.requests, "post", lambda *a, **k: next(reponses))
    monkeypatch.setattr(sig.time, "sleep", attentes.append)
    assert sig.Reranker(url="u", cle="k").scores("q", ["a"]) == [0.5]
    assert attentes == [3.0]                                   # délai indiqué par le service respecté


def test_client_reranker_abandonne_apres_les_tentatives(monkeypatch):
    class Reponse:
        status_code, headers = 429, {}
        def raise_for_status(self): raise sig.requests.HTTPError("429")
    monkeypatch.setattr(sig.requests, "post", lambda *a, **k: Reponse())
    monkeypatch.setattr(sig.time, "sleep", lambda s: None)
    with pytest.raises(sig.requests.HTTPError):
        sig.Reranker(url="u", cle="k", tentatives=3).scores("q", ["a"])
